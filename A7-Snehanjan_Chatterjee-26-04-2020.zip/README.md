# Student Management System
Form background color : #9152f8;

Font : 'Fira Sans', sans-serif;

## Login Page

If user has no account, he can go to Sign Up page for registration.Upon successful registration message will be show.
<br>
User must enter password in valid format. If username and password matches, a session is created and user goes to dashboard.

## Dashboard

Here user can see his detail as well as other student's details.
<br>
User can go to My Profile page to see his profile.
<br>
If the user Sign outs, the session is destroyed and the user is directed to login page.

## My Profile

Here user can see his profile, edit his profile or Signout.
<br>
If the student edits his profile after returning back to My Profile page the details are updated.

## Edit Details

Here user can edit his profile.Address and mobile no are pre loaded, and he will be redirected to My Profile Page.
<br>
Or, he can opt ouf of editing his profile by pressing the cancel button.